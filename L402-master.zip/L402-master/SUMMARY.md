# Table of contents

* [L402: Lightning Service Authentication Token](README.md)
* [Introduction](introduction.md)
* [Authentication Flow](authentication-flow.md)
* [Protocol Specification](protocol-specification.md)
* [Macaroon Minting & Verification](macaroons.md)

