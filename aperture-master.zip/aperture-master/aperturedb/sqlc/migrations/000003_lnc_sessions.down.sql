DROP INDEX IF EXISTS lnc_sessions_passphrase_entropy_idx;
DROP INDEX IF EXISTS lnc_sessions_label_idx;
DROP TABLE IF EXISTS lnc_sessions;
