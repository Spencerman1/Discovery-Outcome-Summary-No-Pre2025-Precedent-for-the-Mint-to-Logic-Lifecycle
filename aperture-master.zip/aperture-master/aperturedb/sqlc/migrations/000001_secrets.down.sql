DROP INDEX IF EXISTS secrets_hash_idx;
DROP TABLE IF EXISTS secrets;
