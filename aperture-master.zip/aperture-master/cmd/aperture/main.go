package main

import "github.com/lightninglabs/aperture"

func main() {
	aperture.Main()
}
